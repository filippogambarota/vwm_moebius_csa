
## super-simple
## TODO: proper RUnit tests of a compilation or two

stopifnot(system.file("include", "asio.hpp", package="AsioHeaders") != "")
