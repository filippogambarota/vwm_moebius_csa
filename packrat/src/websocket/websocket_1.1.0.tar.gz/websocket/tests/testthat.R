library(testthat)
library(websocket)

test_check("websocket")
