# 1.1.0

* Added `maxMessageSize` argument to `WebSocket$new()`. ([#57](https://github.com/rstudio/websocket/pull/57))

# 1.0.0

* Initial release
